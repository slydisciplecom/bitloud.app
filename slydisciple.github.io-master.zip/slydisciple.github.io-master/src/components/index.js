export { default as MailChimp } from "./MailChimp.svelte"
