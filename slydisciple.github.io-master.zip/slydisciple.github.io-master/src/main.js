import App from "./App.svelte"

export default new App({
    target: document.querySelector("#app")
})
